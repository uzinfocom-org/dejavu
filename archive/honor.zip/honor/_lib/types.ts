export interface ParsedRequest {
  full_name: string | undefined;
}
